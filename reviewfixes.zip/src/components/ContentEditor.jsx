import React, { useState, useEffect, useMemo, useRef } from 'react'
import { useLang } from '../lang'
import { useData } from '../data-context'

// ════════════════════════════════════════════════════════════════════
// SCHEMAS — describe each section's editable structure
// type: 'str' | 'num' | 'text' | 'bi' | 'bi-text' | 'str-arr' | 'obj-arr' | 'obj' | 'raw'
// ════════════════════════════════════════════════════════════════════

const journeyItem = [
  { key: 'id',      type: 'num',     label: 'ID' },
  { key: 'year',    type: 'str',     label: '年份 Year' },
  { key: 'label',   type: 'bi',      label: '标签 Label' },
  { key: 'place',   type: 'bi',      label: '地点 Place' },
  { key: 'title',   type: 'bi',      label: '标题 Title（可用 *星号* 强调）' },
  { key: 'text',    type: 'bi-text', label: '正文 Text' },
  { key: 'tags',    type: 'str-arr', label: '标签 Tags' },
  { key: 'chapter', type: 'str',     label: '章节 Chapter (I/II/III/IV)' },
]

const workItem = [
  { key: 'id',       type: 'str',     label: 'ID' },
  { key: 'title',    type: 'bi',      label: '标题 Title' },
  { key: 'subtitle', type: 'bi',      label: '副标题 Subtitle' },
  { key: 'medium',   type: 'str',     label: '媒介 Medium（要跟 Works.jsx 的 WORK_MEDIA 对得上）' },
  { key: 'role',     type: 'bi',      label: '角色 Role' },
  { key: 'year',     type: 'str',     label: '年份 Year' },
  { key: 'cover',    type: 'str',     label: 'CSS 封面 class（cover-1..4）' },
  { key: 'coverImg', type: 'str',     label: '封面图片路径（可选）/picture/xxx.jpg' },
  { key: 'summary',  type: 'bi-text', label: '简介 Summary' },
  { key: 'tags',     type: 'str-arr', label: '标签 Tags' },
  { key: 'field',    type: 'obj',     label: '元信息 Field',
    fields: [
      { key: 'year',      type: 'str', label: '年' },
      { key: 'format',    type: 'bi',  label: '格式' },
      { key: 'role',      type: 'bi',  label: '角色' },
      { key: 'crew',      type: 'bi',  label: '团队' },
      { key: 'festivals', type: 'bi',  label: '展映' },
      { key: 'status',    type: 'bi',  label: '状态' },
    ]
  },
  { key: 'body', type: 'obj-arr', label: '正文段落 Body',
    titleFor: (b, i) => `段落 ${i + 1}`,
    itemSchema: { type: 'bi-text-bare' }  // each item is itself a bilingual string
  },
]

const bookItem = [
  { key: 'title',  type: 'bi',      label: '书名 Title' },
  { key: 'author', type: 'str',     label: '作者 Author' },
  { key: 'year',   type: 'str',     label: '年份 Year' },
  { key: 'stars',  type: 'num',     label: '星级 Stars (1-5)' },
  { key: 'color',  type: 'str',     label: '封面背景色 #hex' },
  { key: 'text',   type: 'str',     label: '封面文字色 #hex' },
  { key: 'note',   type: 'bi-text', label: '书评 Note' },
]

const filmItem = [
  { key: 'title',    type: 'str',     label: '片名 Title' },
  { key: 'subtitle', type: 'str',     label: '原名 / 中文名' },
  { key: 'year',     type: 'str',     label: '年份 Year' },
  { key: 'director', type: 'str',     label: '导演 Director' },
  { key: 'note',     type: 'bi-text', label: '影评 Note' },
]

const musicItem = [
  { key: 'track',     type: 'str',     label: '曲目 Track' },
  { key: 'artist',    type: 'str',     label: '艺人 Artist' },
  { key: 'album',     type: 'str',     label: '专辑 Album' },
  { key: 'duration',  type: 'str',     label: '时长 Duration' },
  { key: 'mood',      type: 'bi',      label: '心境 Mood' },
  { key: 'note',      type: 'bi-text', label: '感受 Note' },
  { key: 'spotifyId', type: 'str',     label: 'Spotify ID（可选，填了能点击播放）' },
  { key: 'neteaseId', type: 'str',     label: '网易云 ID（可选）' },
  { key: 'audio',     type: 'str',     label: '本地音频路径（可选）/audio/xxx.mp3' },
]

const travelItem = [
  { key: 'city',    type: 'bi',  label: '城市 City' },
  { key: 'country', type: 'bi',  label: '国家 Country' },
  { key: 'year',    type: 'str', label: '年份 Year（数字或字符串都行）' },
  { key: 'kind',    type: 'str', label: '类型 Kind (home/frequent/festival/trip)' },
  { key: 'lat',     type: 'num', label: '纬度 Lat（0=不在地图上显示）' },
  { key: 'lon',     type: 'num', label: '经度 Lon' },
  { key: 'note',    type: 'bi',  label: '备注 Note' },
]

const navItem = [
  { key: 'num',   type: 'str', label: '编号' },
  { key: 'id',    type: 'str', label: 'ID (锚点)' },
  { key: 'label', type: 'bi',  label: '主标签' },
  { key: 'en',    type: 'bi',  label: '副标签' },
]

const nowPlayingTrack = [
  { key: 'track',     type: 'bi',  label: '曲目（可双语）' },
  { key: 'artist',    type: 'bi',  label: '艺人（可双语）' },
  { key: 'spotifyId', type: 'str', label: 'Spotify ID' },
  { key: 'neteaseId', type: 'str', label: '网易云 ID' },
  { key: 'audio',     type: 'str', label: '本地音频路径' },
]

const SECTIONS = [
  { key: 'SITE',        label: 'SITE — 站点信息',  type: 'object',  schema: 'site' },
  { key: 'ABOUT',       label: 'ABOUT — 关于',     type: 'object',  schema: 'about' },
  { key: 'TEXTS',       label: 'TEXTS — UI 文字',  type: 'raw',     hint: '硬编码文字（章节标题、印章字、Contact 段落等）。结构比较深，建议用 JSON 直接编辑。' },
  { key: 'JOURNEY',     label: 'JOURNEY — 时间线', type: 'array',   itemSchema: journeyItem, titleFor: (e) => `${e.year ?? '?'} · ${typeof e.label === 'object' ? e.label?.en : e.label}` },
  { key: 'WORKS',       label: 'WORKS — 作品集',   type: 'array',   itemSchema: workItem,   titleFor: (e) => `${typeof e.title === 'object' ? e.title?.en : e.title} (${e.year ?? '?'})` },
  { key: 'BOOKS',       label: 'BOOKS — 书',       type: 'array',   itemSchema: bookItem,   titleFor: (e) => `${typeof e.title === 'object' ? e.title?.en : e.title} — ${e.author}` },
  { key: 'FILMS',       label: 'FILMS — 影',       type: 'array',   itemSchema: filmItem,   titleFor: (e) => `${e.title} (${e.year})` },
  { key: 'MUSIC',       label: 'MUSIC — 音',       type: 'array',   itemSchema: musicItem,  titleFor: (e) => `${e.track} — ${e.artist}` },
  { key: 'TRAVEL',      label: 'TRAVEL — 足迹',    type: 'array',   itemSchema: travelItem, titleFor: (e) => `${typeof e.city === 'object' ? e.city?.en : e.city} (${e.year})` },
  { key: 'NAV',         label: 'NAV — 导航',       type: 'array',   itemSchema: navItem,    titleFor: (e) => `${e.num} ${typeof e.label === 'object' ? e.label?.en : e.label}` },
  { key: 'NOW_PLAYING', label: 'NOW_PLAYING — 播放器歌单', type: 'now-playing', itemSchema: nowPlayingTrack },
]

const SITE_SCHEMA = [
  { key: 'name',         type: 'bi',      label: '简称 Name' },
  { key: 'nameFull',     type: 'bi',      label: '全名 Full name' },
  { key: 'glyph',        type: 'str',     label: '首字符 Glyph' },
  { key: 'portrait',     type: 'str',     label: '头像路径 Portrait（如 /picture/xxx.jpg）' },
  { key: 'tagline',      type: 'bi-text', label: '标语 Tagline' },
  { key: 'role',         type: 'bi',      label: '身份 Role' },
  { key: 'status',       type: 'bi',      label: '状态标签 Status' },
  { key: 'statusObject', type: 'bi',      label: '当前在做 Status object' },
  { key: 'location',     type: 'bi',      label: '位置 Location' },
  { key: 'timezone',     type: 'str',     label: '时区显示文本（如 UTC+8）' },
  { key: 'tzName',       type: 'str',     label: '时区 IANA 名（如 Asia/Shanghai / America/New_York · Frame 00 时钟用）' },
  { key: 'email',        type: 'str',     label: '邮箱 Email' },
  { key: 'now',          type: 'bi-text', label: '正在做什么 Now（长段）' },
  { key: 'nowDate',      type: 'bi',      label: '更新时间标签 Now date' },
  { key: 'social',       type: 'obj-arr', label: '社交账号 Social',
    titleFor: (s) => (typeof s.label === 'object' ? s.label?.en : s.label) + ' · ' + s.handle,
    itemSchema: [
      { key: 'label',  type: 'bi',  label: '名称' },
      { key: 'handle', type: 'str', label: '账号' },
      { key: 'url',    type: 'str', label: '链接 URL' },
    ],
  },
]

const ABOUT_SCHEMA = [
  { key: 'intro',      type: 'bi-text', label: '首段（首字下沉）Intro' },
  { key: 'paragraphs', type: 'obj-arr', label: '后续段落 Paragraphs',
    titleFor: (_, i) => `段落 ${i + 1}`, itemSchema: { type: 'bi-text-bare' } },
  { key: 'stats',      type: 'obj-arr', label: '统计格 Stats',
    titleFor: (s) => (typeof s.label === 'object' ? s.label?.en : s.label),
    itemSchema: [
      { key: 'label', type: 'bi', label: '名称' },
      { key: 'value', type: 'bi', label: '值（可用 *星号* 高亮）' },
    ],
  },
  { key: 'cv', type: 'obj', label: '简历 CV',
    fields: [
      { key: 'edu',    type: 'obj-arr', label: '学历 Education', titleFor: (e) => e.year, itemSchema: cvSubItem() },
      { key: 'work',   type: 'obj-arr', label: '工作 Practice', titleFor: (e) => e.year, itemSchema: cvSubItem() },
      { key: 'awards', type: 'obj-arr', label: '奖项 Awards',   titleFor: (e) => e.year, itemSchema: cvSubItem() },
      { key: 'skills', type: 'obj-arr', label: '技能 Skills',   titleFor: (e) => e.year, itemSchema: cvSubItem() },
    ],
  },
]

function cvSubItem() {
  return [
    { key: 'year',  type: 'str', label: '年/分类' },
    { key: 'title', type: 'bi',  label: '标题' },
    { key: 'role',  type: 'bi',  label: '描述' },
    { key: 'place', type: 'bi',  label: '地点' },
  ]
}

// ════════════════════════════════════════════════════════════════════
// JS LITERAL FORMATTER — produces code that can be pasted into data.js
// ════════════════════════════════════════════════════════════════════
function jsLiteral(value, indent = '') {
  if (value === null || value === undefined) return 'null'
  if (typeof value === 'string') return strLit(value)
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  if (Array.isArray(value)) {
    if (value.length === 0) return '[]'
    const items = value.map((v) => indent + '  ' + jsLiteral(v, indent + '  '))
    return '[\n' + items.join(',\n') + '\n' + indent + ']'
  }
  if (typeof value === 'object') {
    const keys = Object.keys(value)
    if (keys.length === 2 && 'en' in value && 'zh' in value) {
      return `L(${strLit(value.en)}, ${strLit(value.zh)})`
    }
    if (keys.length === 0) return '{}'
    const items = keys.map((k) => indent + '  ' + safeKey(k) + ': ' + jsLiteral(value[k], indent + '  '))
    return '{\n' + items.join(',\n') + '\n' + indent + '}'
  }
  return String(value)
}

function strLit(s) {
  const v = s ?? ''
  // Single-quoted string with proper escapes
  return "'" + String(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, '\\n') + "'"
}

function safeKey(k) {
  return /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(k) ? k : strLit(k)
}

function exportLine(name, value) {
  return `export const ${name} = ${jsLiteral(value)}`
}

// ════════════════════════════════════════════════════════════════════
// FIELD COMPONENTS
// ════════════════════════════════════════════════════════════════════

function StringField({ value, onChange, placeholder, multiline }) {
  if (multiline) {
    return <textarea
      className="ce-input ce-textarea"
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      rows={3}
    />
  }
  return <input
    className="ce-input"
    type="text"
    value={value ?? ''}
    onChange={(e) => onChange(e.target.value)}
    placeholder={placeholder}
  />
}

function NumberField({ value, onChange, placeholder }) {
  return <input
    className="ce-input"
    type="number"
    value={value ?? ''}
    onChange={(e) => onChange(e.target.value === '' ? undefined : Number(e.target.value))}
    placeholder={placeholder}
  />
}

function BilingualField({ value, onChange, multiline }) {
  const v = value && typeof value === 'object' ? value : { en: typeof value === 'string' ? value : '', zh: '' }
  const setEn = (en) => onChange({ ...v, en })
  const setZh = (zh) => onChange({ ...v, zh })
  return (
    <div className="ce-bi">
      <div>
        <span className="ce-bi-lbl">EN</span>
        <StringField value={v.en} onChange={setEn} multiline={multiline} placeholder="English..." />
      </div>
      <div>
        <span className="ce-bi-lbl">中文</span>
        <StringField value={v.zh} onChange={setZh} multiline={multiline} placeholder="中文..." />
      </div>
    </div>
  )
}

function StringArrayField({ value, onChange }) {
  const arr = Array.isArray(value) ? value : []
  const update = (i, v) => onChange(arr.map((x, k) => (k === i ? v : x)))
  const remove = (i) => onChange(arr.filter((_, k) => k !== i))
  const add = () => onChange([...arr, ''])
  return (
    <div className="ce-str-arr">
      {arr.map((s, i) => (
        <div key={i} className="ce-str-arr-row">
          <input className="ce-input" type="text" value={s} onChange={(e) => update(i, e.target.value)} />
          <button type="button" className="ce-icon-btn" onClick={() => remove(i)} aria-label="remove">×</button>
        </div>
      ))}
      <button type="button" className="ce-add-btn" onClick={add}>+ 添加</button>
    </div>
  )
}

function ObjectField({ value, onChange, fields }) {
  const v = value && typeof value === 'object' ? value : {}
  const setKey = (k, kv) => onChange({ ...v, [k]: kv })
  return (
    <div className="ce-obj">
      {fields.map((f) => (
        <FieldRow key={f.key} field={f} value={v[f.key]} onChange={(kv) => setKey(f.key, kv)} />
      ))}
    </div>
  )
}

function ObjectArrayField({ value, onChange, itemSchema, titleFor }) {
  const arr = Array.isArray(value) ? value : []
  const [expanded, setExpanded] = useState({})

  const update = (i, v) => onChange(arr.map((x, k) => (k === i ? v : x)))
  const remove = (i) => {
    if (!window.confirm('删除这一项？')) return
    onChange(arr.filter((_, k) => k !== i))
    setExpanded((e) => { const n = { ...e }; delete n[i]; return n })
  }
  const add = () => {
    const empty = createEmpty(itemSchema)
    onChange([...arr, empty])
    setExpanded((e) => ({ ...e, [arr.length]: true }))
  }
  const move = (i, dir) => {
    const j = i + dir
    if (j < 0 || j >= arr.length) return
    const next = arr.slice()
    ;[next[i], next[j]] = [next[j], next[i]]
    onChange(next)
  }

  return (
    <div className="ce-arr">
      {arr.map((item, i) => {
        const title = titleFor ? titleFor(item, i) : `Item ${i + 1}`
        const isOpen = expanded[i]
        return (
          <div key={i} className={`ce-arr-card ${isOpen ? 'open' : ''}`}>
            <div className="ce-arr-card-head">
              <button type="button" className="ce-arr-card-toggle" onClick={() => setExpanded((e) => ({ ...e, [i]: !e[i] }))}>
                <span className="ce-arr-card-chevron">{isOpen ? '▼' : '▶'}</span>
                <span className="ce-arr-card-title">{title || '(empty)'}</span>
              </button>
              <div className="ce-arr-card-actions">
                <button type="button" className="ce-icon-btn" onClick={() => move(i, -1)} disabled={i === 0} title="上移">↑</button>
                <button type="button" className="ce-icon-btn" onClick={() => move(i, +1)} disabled={i === arr.length - 1} title="下移">↓</button>
                <button type="button" className="ce-icon-btn ce-danger" onClick={() => remove(i)} title="删除">×</button>
              </div>
            </div>
            {isOpen && (
              <div className="ce-arr-card-body">
                {Array.isArray(itemSchema)
                  ? itemSchema.map((f) => (
                      <FieldRow key={f.key} field={f} value={item?.[f.key]}
                        onChange={(kv) => update(i, { ...item, [f.key]: kv })} />
                    ))
                  : (
                    // Single-field items (e.g. paragraphs as bilingual strings)
                    <SingleItemEditor schema={itemSchema} value={item} onChange={(v) => update(i, v)} />
                  )}
              </div>
            )}
          </div>
        )
      })}
      <button type="button" className="ce-add-btn ce-add-arr" onClick={add}>+ 新增一项</button>
    </div>
  )
}

function SingleItemEditor({ schema, value, onChange }) {
  const fakeField = { ...schema, key: '_', label: '' }
  return <FieldRow field={fakeField} value={value} onChange={onChange} hideLabel />
}

// Generic field row — picks the right input component for the field type.
function FieldRow({ field, value, onChange, hideLabel }) {
  const Body = () => {
    switch (field.type) {
      case 'str':       return <StringField value={value} onChange={onChange} placeholder={field.placeholder} />
      case 'text':      return <StringField value={value} onChange={onChange} multiline placeholder={field.placeholder} />
      case 'num':       return <NumberField value={value} onChange={onChange} placeholder={field.placeholder} />
      case 'bi':        return <BilingualField value={value} onChange={onChange} />
      case 'bi-text':
      case 'bi-text-bare': return <BilingualField value={value} onChange={onChange} multiline />
      case 'str-arr':   return <StringArrayField value={value} onChange={onChange} />
      case 'obj':       return <ObjectField value={value} onChange={onChange} fields={field.fields} />
      case 'obj-arr':   return <ObjectArrayField value={value} onChange={onChange} itemSchema={field.itemSchema} titleFor={field.titleFor} />
      default:          return <code className="ce-unsupported">未支持的字段类型: {field.type}</code>
    }
  }
  return (
    <div className={`ce-field ce-field-${field.type}`}>
      {!hideLabel && <label className="ce-field-label">{field.label || field.key}</label>}
      <div className="ce-field-input"><Body /></div>
    </div>
  )
}

// Create an empty value matching a schema (for "+ add new")
function createEmpty(schema) {
  if (!Array.isArray(schema)) {
    // Single-field item — return empty value for that type
    if (schema?.type === 'bi' || schema?.type === 'bi-text' || schema?.type === 'bi-text-bare') return { en: '', zh: '' }
    if (schema?.type === 'num') return 0
    return ''
  }
  const obj = {}
  for (const f of schema) {
    if (f.type === 'bi' || f.type === 'bi-text') obj[f.key] = { en: '', zh: '' }
    else if (f.type === 'num') obj[f.key] = 0
    else if (f.type === 'str-arr') obj[f.key] = []
    else if (f.type === 'obj-arr') obj[f.key] = []
    else if (f.type === 'obj') obj[f.key] = createEmpty(f.fields)
    else obj[f.key] = ''
  }
  return obj
}

// ════════════════════════════════════════════════════════════════════
// JSON RAW EDITOR — for sections too complex for schema (TEXTS)
// ════════════════════════════════════════════════════════════════════
function JsonEditor({ value, onChange }) {
  const [text, setText] = useState(() => JSON.stringify(value, null, 2))
  const [err, setErr] = useState('')

  useEffect(() => {
    setText(JSON.stringify(value, null, 2))
  }, [value])

  const tryParse = (s) => {
    try {
      const parsed = JSON.parse(s)
      setErr('')
      onChange(parsed)
    } catch (e) {
      setErr(e.message)
    }
  }

  return (
    <div className="ce-json">
      <textarea
        className="ce-input ce-json-textarea"
        value={text}
        onChange={(e) => { setText(e.target.value); tryParse(e.target.value) }}
        spellCheck={false}
      />
      {err && <div className="ce-json-err">JSON 错误：{err}</div>}
    </div>
  )
}

// ════════════════════════════════════════════════════════════════════
// SECTION EDITORS
// ════════════════════════════════════════════════════════════════════

function SectionEditor({ section, value, onChange }) {
  if (section.key === 'SITE') {
    return <ObjectField value={value} onChange={onChange} fields={SITE_SCHEMA} />
  }
  if (section.key === 'ABOUT') {
    return <ObjectField value={value} onChange={onChange} fields={ABOUT_SCHEMA} />
  }
  if (section.type === 'array') {
    return (
      <ObjectArrayField
        value={value}
        onChange={onChange}
        itemSchema={section.itemSchema}
        titleFor={section.titleFor}
      />
    )
  }
  if (section.type === 'now-playing') {
    const v = value || { spotify: [], netease: [], html5: [] }
    return (
      <div className="ce-np-editor">
        {['spotify', 'netease', 'html5'].map((src) => (
          <div key={src} className="ce-np-group">
            <h4 className="ce-np-group-title">{src.toUpperCase()}</h4>
            <ObjectArrayField
              value={v[src] || []}
              onChange={(arr) => onChange({ ...v, [src]: arr })}
              itemSchema={section.itemSchema}
              titleFor={(e) => (typeof e.track === 'object' ? e.track?.en : e.track) || '(empty)'}
            />
          </div>
        ))}
      </div>
    )
  }
  if (section.type === 'raw') {
    return (
      <>
        {section.hint && <p className="ce-hint">{section.hint}</p>}
        <JsonEditor value={value} onChange={onChange} />
      </>
    )
  }
  return <p>未实现的章节类型：{section.type}</p>
}

// ════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ════════════════════════════════════════════════════════════════════
export default function ContentEditor({ open, onClose }) {
  const { lang } = useLang()
  const data = useData()
  const [activeKey, setActiveKey] = useState('SITE')
  // Local working copy — only commits to context when user clicks Save
  const [workingValue, setWorkingValue] = useState(null)
  const [showCode, setShowCode] = useState(false)
  const [copied, setCopied] = useState('')
  // Display mode: 'modal' (full-screen overlay) or 'side' (right side panel, site stays visible)
  const [mode, setMode] = useState(() => {
    try { return localStorage.getItem('chen.ce.mode') === 'side' ? 'side' : 'modal' } catch { return 'modal' }
  })
  // Auto-save toggle: if on, edits commit to context on every change (live preview)
  const [autoSave, setAutoSave] = useState(() => {
    try { return localStorage.getItem('chen.ce.autosave') === '1' } catch { return false }
  })

  useEffect(() => { try { localStorage.setItem('chen.ce.mode', mode) } catch {} }, [mode])
  useEffect(() => { try { localStorage.setItem('chen.ce.autosave', autoSave ? '1' : '0') } catch {} }, [autoSave])

  // Sync working value when section changes
  useEffect(() => {
    if (!open) return
    setWorkingValue(deepClone(data[activeKey]))
    setShowCode(false)
  }, [activeKey, open])

  // Auto-save: when workingValue changes, push to context (debounced)
  useEffect(() => {
    if (!autoSave || workingValue == null) return
    const id = setTimeout(() => {
      data.setSection(activeKey, workingValue)
    }, 400)
    return () => clearTimeout(id)
  }, [workingValue, autoSave, activeKey])

  // On tab change OR close, flush any pending auto-save edits so they're not lost
  // mid-debounce. Uses a ref so the cleanup sees the latest values.
  const flushRef = useRef({ autoSave, workingValue, activeKey })
  useEffect(() => { flushRef.current = { autoSave, workingValue, activeKey } })
  useEffect(() => {
    return () => {
      const { autoSave: a, workingValue: wv, activeKey: ak } = flushRef.current
      if (a && wv != null) data.setSection(ak, wv)
    }
  }, [activeKey, open])
  // eslint-disable-next-line react-hooks/exhaustive-deps

  // Body scroll lock — only in modal mode
  useEffect(() => {
    if (!open) return
    if (mode === 'modal') {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    const onKey = (e) => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open, mode, onClose])

  if (!open) return null

  const section = SECTIONS.find(s => s.key === activeKey)
  const isOverridden = data.isOverridden(activeKey)

  const handleSave = () => {
    data.setSection(activeKey, workingValue)
    flash(setCopied, '✓ 已保存到浏览器（实时生效）')
  }
  const handleReset = () => {
    if (!window.confirm(`重置 ${activeKey} 到代码默认值？localStorage 里的编辑会丢失。`)) return
    data.resetSection(activeKey)
    setWorkingValue(deepClone(data.defaults[activeKey]))
    flash(setCopied, '↺ 已重置到代码默认值')
  }
  const handleCopy = () => {
    const code = exportLine(activeKey, workingValue)
    navigator.clipboard.writeText(code).then(() => {
      flash(setCopied, '✓ 已复制代码到剪贴板')
    }, () => {
      flash(setCopied, '✗ 复制失败，请手动选中下方代码块')
    })
  }
  const handleCopyAll = () => {
    const blob = SECTIONS
      .filter(s => s.key !== 'NAV')
      .map(s => exportLine(s.key, data[s.key]))
      .join('\n\n')
    navigator.clipboard.writeText(blob).then(() => {
      flash(setCopied, '✓ 已复制全部 export 到剪贴板')
    })
  }

  return (
    <div className={`ce-overlay mode-${mode}`}>
      <div className="ce-shell">
        <header className="ce-header">
          <div className="ce-title">
            <span className="ce-title-main">{lang === 'zh' ? '内容编辑器' : 'Content Editor'}</span>
            <span className="ce-title-sub">
              {mode === 'side'
                ? (lang === 'zh' ? '侧栏模式 · 左侧主站可实时预览' : 'Side mode · live preview on the left')
                : (lang === 'zh' ? '保存到浏览器即时生效；复制代码粘贴到 data.js 永久保存' : 'Save → live preview · copy code → paste into data.js to persist')}
            </span>
          </div>
          <div className="ce-header-actions">
            <label className="ce-autosave" title={lang === 'zh' ? '改完自动保存到浏览器' : 'Auto-save edits to browser'}>
              <input type="checkbox" checked={autoSave} onChange={(e) => setAutoSave(e.target.checked)} />
              <span>{lang === 'zh' ? '自动保存' : 'Auto-save'}</span>
            </label>
            <button
              className="ce-mode-toggle"
              onClick={() => setMode(m => m === 'modal' ? 'side' : 'modal')}
              title={lang === 'zh' ? '切换布局模式' : 'Toggle layout'}
            >
              {mode === 'modal' ? '⊟ ' + (lang === 'zh' ? '侧栏' : 'Side') : '⊞ ' + (lang === 'zh' ? '全屏' : 'Modal')}
            </button>
            <button className="ce-btn ce-btn-ghost" onClick={handleCopyAll} title="复制所有 export">📋 {lang === 'zh' ? '全部' : 'All'}</button>
            <button className="ce-close" onClick={onClose} aria-label="close">✕</button>
          </div>
        </header>

        <div className="ce-body">
          <nav className="ce-tabs" aria-label="sections">
            {SECTIONS.map(s => (
              <button
                key={s.key}
                className={`ce-tab ${activeKey === s.key ? 'act' : ''}`}
                onClick={() => setActiveKey(s.key)}
              >
                <span className="ce-tab-label">{s.label}</span>
                {data.isOverridden(s.key) && <span className="ce-tab-dot" title="已被本地编辑过">●</span>}
              </button>
            ))}
          </nav>

          <main className="ce-main">
            <div className="ce-main-head">
              <h3 className="ce-section-title">{section.label}</h3>
              {isOverridden && <span className="ce-tag">本地编辑中</span>}
            </div>

            {workingValue !== null && (
              <div className="ce-section-body">
                <SectionEditor section={section} value={workingValue} onChange={setWorkingValue} />
              </div>
            )}

            {showCode && (
              <div className="ce-code-block">
                <div className="ce-code-head">
                  <span>{activeKey} 导出代码 — 复制到 data.js</span>
                  <button className="ce-btn ce-btn-ghost" onClick={handleCopy}>📋 复制</button>
                </div>
                <pre className="ce-code"><code>{exportLine(activeKey, workingValue)}</code></pre>
              </div>
            )}
          </main>
        </div>

        <footer className="ce-footer">
          <div className="ce-footer-msg">{copied}</div>
          <div className="ce-footer-actions">
            <button className="ce-btn ce-btn-ghost" onClick={handleReset} disabled={!isOverridden}>↺ 重置本章</button>
            <button className="ce-btn ce-btn-ghost" onClick={() => setShowCode(s => !s)}>
              {showCode ? '隐藏代码' : '< />  查看代码'}
            </button>
            <button className="ce-btn" onClick={handleSave}>💾 保存到浏览器</button>
          </div>
        </footer>
      </div>
    </div>
  )
}

function deepClone(v) {
  return typeof structuredClone === 'function' ? structuredClone(v) : JSON.parse(JSON.stringify(v))
}

function flash(setter, msg) {
  setter(msg)
  setTimeout(() => setter(''), 2400)
}
