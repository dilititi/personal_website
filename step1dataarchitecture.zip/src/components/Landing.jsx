import React from 'react'
import { useLang } from '../lang'
import { useData } from '../data-context'
import { useClock, formatTime } from '../hooks'

export default function Landing({ onJump }) {
  const { t } = useLang()
  const { SITE, TEXTS } = useData()
  const TL = TEXTS.landing
  const now = useClock()

  return (
    <section id="home" className="landing landing-masthead">
      <div className="landing-bg"></div>

      <div className="mh-content">
        <div className="mh-name">
          <div className="mh-name-l">{t(TL.nameLeft)}</div>
          <div className="mh-name-r"><i>{t(TL.nameRight)}</i></div>
        </div>

        <div className="mh-rule"></div>

        <div className="mh-meta">
          <span className="mh-meta-c">{t(TL.metaRole)}</span>
          <span className="mh-meta-c">{t(TL.metaSchool)}</span>
          <a className="mh-meta-c link" href={`mailto:${SITE.email}`}>{t(TL.metaEmailLbl)}</a>
          <span className="mh-meta-c right">{t(TL.metaCity)} {formatTime(now, SITE.tzName || 'Asia/Shanghai')}</span>
        </div>

        <div className="mh-statement">
          <div className="mh-row">
            <button className="mh-pill pill-about" onClick={() => onJump('about')}>
              <span>{t(TL.pillAboutLbl)}</span>
              <em>01</em>
            </button>
            <span className="mh-word">{t(TL.wordA)}</span>
            <button className="mh-pill pill-works" onClick={() => onJump('works')}>
              <span>{t(TL.pillWorksLbl)}</span>
              <em>02</em>
            </button>
          </div>

          <div className="mh-rule"></div>

          <div className="mh-row mh-row-mid">
            <span className="mh-word mh-word-full">{t(TL.wordB)}</span>
          </div>

          <div className="mh-rule"></div>

          <div className="mh-row">
            <span className="mh-word">{t(TL.wordC)}</span>
            <button className="mh-pill pill-library" onClick={() => onJump('library')}>
              <span>{t(TL.pillLibraryLbl)}</span>
              <em>03</em>
            </button>
            <span className="mh-word">{t(TL.wordD)}</span>
          </div>

          <div className="mh-rule"></div>
        </div>
      </div>
    </section>
  )
}
