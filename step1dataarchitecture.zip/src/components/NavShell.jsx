import React from 'react'
import { useLang } from '../lang'
import { useData } from '../data-context'
import { useActiveSection } from '../hooks'

function LangToggle() {
  const { lang, setLang } = useLang()
  return (
    <div className="lang-toggle">
      <button className={lang === 'en' ? 'active' : ''} onClick={() => setLang('en')}>EN</button>
      <button className={lang === 'zh' ? 'active' : ''} onClick={() => setLang('zh')}>中</button>
    </div>
  )
}

function BottomStrip({ activeId, onJump }) {
  const { t } = useLang()
  const { NAV } = useData()
  return (
    <nav className="bottom-strip" aria-label="Sections">
      {NAV.map((n) => (
        <button
          key={n.id}
          className={`bs-ch ${activeId === n.id ? 'act' : ''}`}
          onClick={() => onJump(n.id)}
          aria-current={activeId === n.id ? 'true' : undefined}
        >
          <span className="bs-num">{n.num}</span>
          <span className="bs-lb">{t(n.label)}</span>
        </button>
      ))}
    </nav>
  )
}

function TopBar({ onJump, onOpenEditor }) {
  const { lang, t } = useLang()
  const { SITE } = useData()
  return (
    <div className="top-bar">
      <button className="nav-mark" onClick={() => onJump('home')}>
        <span className="dot"></span>
        <span>{t(SITE.name)} · {t(SITE.location)}</span>
      </button>
      <div className="top-bar-right">
        {onOpenEditor && (
          <button
            className="top-bar-tool-btn"
            onClick={onOpenEditor}
            title={lang === 'zh' ? '内容编辑器' : 'Content editor'}
          >
            ✏️ <span>{lang === 'zh' ? '编辑' : 'Edit'}</span>
          </button>
        )}
        <LangToggle />
      </div>
    </div>
  )
}

export default function NavShell({ onJump, onOpenEditor }) {
  const { NAV } = useData()
  const active = useActiveSection(NAV.map(n => n.id))
  return (
    <>
      <TopBar onJump={onJump} onOpenEditor={onOpenEditor} />
      <BottomStrip activeId={active} onJump={onJump} />
    </>
  )
}
