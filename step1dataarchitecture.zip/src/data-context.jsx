import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import * as defaults from './data'

const STORAGE_KEY = 'chen.content.overrides'
const DataContext = createContext(null)

// All editable section keys, in order they'll show in the editor.
export const SECTION_KEYS = [
  'SITE', 'TEXTS', 'ABOUT', 'JOURNEY',
  'WORKS', 'BOOKS', 'FILMS', 'MUSIC',
  'TRAVEL', 'NOW_PLAYING', 'NAV',
]

function loadOverrides() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : {}
  } catch { return {} }
}

function saveOverrides(obj) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(obj)) }
  catch (e) { console.warn('Content override write failed:', e) }
}

export function useData() {
  const ctx = useContext(DataContext)
  if (!ctx) throw new Error('useData must be used inside <DataProvider>')
  return ctx
}

export function DataProvider({ children }) {
  const [overrides, setOverrides] = useState(loadOverrides)

  useEffect(() => { saveOverrides(overrides) }, [overrides])

  // For object sections (SITE, TEXTS, ABOUT, NOW_PLAYING): shallow-merge override over default.
  // For array sections (JOURNEY, WORKS, etc.): override replaces default entirely.
  // This way, editing one SITE field doesn't drop the others.
  const merge = (key) => {
    const def = defaults[key]
    const ovr = overrides[key]
    if (ovr === undefined) return def
    if (Array.isArray(def)) return ovr
    if (def && typeof def === 'object') return { ...def, ...ovr }
    return ovr
  }

  const value = {
    // Spread all sections
    SITE:         merge('SITE'),
    TEXTS:        merge('TEXTS'),
    ABOUT:        merge('ABOUT'),
    JOURNEY:      merge('JOURNEY'),
    WORKS:        merge('WORKS'),
    BOOKS:        merge('BOOKS'),
    FILMS:        merge('FILMS'),
    MUSIC:        merge('MUSIC'),
    TRAVEL:       merge('TRAVEL'),
    NOW_PLAYING:  merge('NOW_PLAYING'),
    NAV:          merge('NAV'),
    PHOTOS:       defaults.PHOTOS,           // photos have their own upload UI
    PHOTO_SERIES: defaults.PHOTO_SERIES,
    READING_LOG:  defaults.READING_LOG,      // reading log has its own form

    // Mutation methods used by the editor
    overrides,
    setSection: useCallback((key, value) => {
      setOverrides(prev => ({ ...prev, [key]: value }))
    }, []),
    resetSection: useCallback((key) => {
      setOverrides(prev => {
        const next = { ...prev }
        delete next[key]
        return next
      })
    }, []),
    resetAll: useCallback(() => setOverrides({}), []),
    isOverridden: (key) => overrides[key] !== undefined,

    // Re-export helpers
    pick: defaults.pick,
    defaults,
  }

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>
}
